package com.nucleus.springbrd.persistance.dao;



import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nucleus.springbrd.persistance.entity.Customer;






/*********************************************************           
 * CustomerDaoImpl --Database Queries to Implement       *
                     over Customer Records               *   
 *                                                       *   
 * Author:  NIKHIL GUPTA                                 *   
 *                                                       *   
 * Purpose: Perform CRUD operation                       *   
 *                                                       *   
 * Usage: Data can be Added, Viewed, Updated or, Deleted *   
 *      										         *   
 ********************************************************/  



@Repository
@Transactional
public class CustomerDaoImpl implements CustomerDao 
{ 

	@Autowired
	SessionFactory sessionFactory;
	final static Logger log = Logger.getLogger(CustomerDaoImpl.class.getName());
	
	
	


//CRUD - ADD---------------------------------------------------------------------------------
	public Customer addCustomer(Customer customer) 
	{	
	
		Date date = new Date();
		SimpleDateFormat format = new SimpleDateFormat("dd/MMM/yyyy");
		customer.setRegistrationDate(format.format(date));
	try
	{
		log.debug("in Dao for Adding Customer");
		sessionFactory.getCurrentSession().saveOrUpdate(customer);
	}


	catch(HibernateException e)
	{
		log.error("could not add" + e.getMessage());
	}


	catch(Exception e)
	{
		log.error("could not add" + e.getMessage());
	}
		return customer;
	
	}

	







//CRUD - VIEW ALL RECORDS --------------------------------------------------------------------------------------

	@SuppressWarnings("unchecked")
	public List<Customer> getAllCustomers() 
	{
		
		List<Customer> list = new ArrayList<Customer>();
	
		try
		{
			log.debug("in Dao for viewing all Customer");
			Session session = sessionFactory.getCurrentSession();
			list = session.createQuery("from Customer").list();
		}

		catch(HibernateException e)
		{
			log.error("could not Find" + e.getMessage());
		}
		
		catch(Exception e)
		{
			log.error("could not Find" + e.getMessage());
		}
		
		return list;
		
	}





//CRUD - VIEW BY CODE---------------------------------------------------------------------------
	public Customer viewCustomerByCode(int customerCode) 
	{
		
		Customer customer = null;
	
		try
		{
			log.debug("in Dao for viewing Customer code");
			customer = (Customer) sessionFactory.getCurrentSession().get(Customer.class, customerCode);
		}


		catch(HibernateException e)
		{
			log.error("could not Find" + e.getMessage());
		}
		
		catch(Exception e)
		{
			log.error("could not Find" + e.getMessage());
		}


		if(customer!=null)
		{
			return customer;
		}
	
		else
		{
			return null;
		}

	}






//CRUD - VIEW BY NAME-----------------------------------------------------------------------------------------

	@SuppressWarnings("unchecked")
	public List<Customer> getAllCustomersByName(String customerName) 
	{
		log.info("in Dao for viewing Customer by code");
		List<Customer> list = new ArrayList<Customer>();
		try{
		Session session = sessionFactory.getCurrentSession();
		log.debug("in Dao for viewing Customer by code");

		list = session.createQuery("from Customer where customerName='"+customerName+"'").list();
		}
		catch(HibernateException e){
			log.error("could not Find" + e.getMessage());
		}
		catch(Exception e){
			log.error("could not Find" + e.getMessage());
		}
		if(list!=null)
		{
			return list; 
		}
		else
		{
			return null; 
		}
	}











//CRUD - UPDATE RECORD------------------------------------------------------------------------------------
	public Customer updateCustomer(Customer customer) 
	{
		Date date = new Date();
		
		SimpleDateFormat format = new SimpleDateFormat("dd/MMM/yyyy");
	
		try
		{
			log.debug("in Dao for updating Customer");
			customer.setModifiedDate(format.format(date));
			sessionFactory.getCurrentSession().update(customer);
		}
		

		catch(HibernateException e)
		{
			log.error("could not Update" + e.getMessage());
		}

		catch(Exception e)
		{
			log.error("could not Update" + e.getMessage());
		}
	
		return customer;
	}

	



//CRUD - DELETE---------------------------------------------------------------------------------
	public void deleteCustomer(int customerCode) 
	{ 
		
		Customer customer = new Customer();
		customer.setCustomerCode(customerCode);
	
		try
		{
			log.debug("in Dao for Deleting Customer");
			sessionFactory.getCurrentSession().delete(customer);
		}

		catch(HibernateException e)
		{
			log.error("could not Delete" + e.getMessage());
		}

		catch(Exception e)
		{
			log.error("could not Delete" + e.getMessage());
		}
	}

	
}
