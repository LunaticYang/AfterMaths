package com.nucleus.springbrd.persistance.dao;




/********************************************************           
 * CustomerDao: Interface For Dao Operations            *   
 *                                                      *   
 * Author:  NIKHIL GUPTA                                *   
 *                                                      *   
 * Purpose: Declare All the methods implemented in Dao  *   
 *                                                      *   
 * Usage: Implemented upon UserDaoImpl                  *   
 *      	        									*   
 ********************************************************/  

import java.util.List;

import com.nucleus.springbrd.persistance.entity.User;



//Interface: Authenticated User Records to Database handler
public interface UserDao 
{

	public User addUser(User user);

	public void deleteUser(int id);

	public List<User> getAllUser();
}
