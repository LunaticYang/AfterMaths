package com.nucleus.springbrd.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.springbrd.persistance.entity.Customer;
import com.nucleus.springbrd.persistance.entity.User;
import com.nucleus.springbrd.service.CustomerService;
import com.nucleus.springbrd.service.UserService;
import com.nucleus.springbrd.service.ValidationService;


/********************************************************           
 * MainController --Handling  Requests                  *   
 *                                                      *   
 * Author:  NIKHIL GUPTA                                *   
 *                                                      *   
 * Purpose: Handles Authenticated User Request          *   
 *                                                      *   
 * Usage:  Dispatch Page Request                        *   
 *      		                                        *   
 ********************************************************/  





@Controller
public class AdminController 
{


	//Logger to MainController
		final static Logger log = Logger.getLogger(AdminController.class.getName());
		
	
	//AutoWired
		@Autowired
		CustomerService customerService;

		
		@Autowired
		UserService userService;
		

		
		
		
		

//ADMIN SCREEN CONTROL
//===============================================================================================================


			

	//ADMIN Screen Display	
		@RequestMapping(value = "/SplitUser")
		public String loadUser() 
		{
			return "SplitUser";
		}



		
//ADD RECORD		
//-----------------------------------------------------------------------------------------------------------------



	//Add New User-------------------------
		@RequestMapping("/adduser")
		public ModelAndView addUser(User user) 
		{
			log.info("Request To Add a New User/Admin");
			return new ModelAndView("NewUser"); 
		}

		


	//Adding New User------------------------------------------------------
		@RequestMapping("/newUser")
		public ModelAndView addnewUser(@Valid @ModelAttribute("user")User user) 
		{
			log.info("Getting User Details");
			userService.adduser(user);
	
			log.info("User Added");
			return new ModelAndView("NewUser", "message", "New" + user.getRole() + "was added successfully");

		}





//DELETE RECORD
//-----------------------------------------------------------------------------------------------------------------




		//Delete Existing Authenticated User
		@RequestMapping(value = "/deleteUser", method = RequestMethod.GET)
		public String deleteuser() 
		{
			return "getUserCode";
		}
	
		
		//Delete  Selected User
		@RequestMapping(value = "/deleteUser", method = RequestMethod.POST)
		public String deleteUser(Model model, @RequestParam("id") String id) 
		{
			userService.deleteUser(Integer.parseInt(id));
			return "DeleteView";
		}






//VIEW AUTHENTICAED RECORDS
//-----------------------------------------------------------------------------------------------------------------

		
 //View All Authenticated Users
	@RequestMapping(value = "/viewallUser", method = RequestMethod.GET)
	public String viewAll(Model model) 
	{
		log.info("request To View All");
		List<User> user = userService.viewAllUser();

		model.addAttribute("user", user);
		log.info("Displaying All");
		
		return "viewAllUser";

	}




//VIEW CUSTOMER RECORDS: 
//-----------------------------------------------------------------------------------------------------------------			

//View All Records From User Screen------------------------------------ 
	@RequestMapping(value = "/viewallCustomer", method = RequestMethod.GET)
	public String viewallCustomer(Model model) 
	{

		List<Customer> customer = customerService.viewAll();
		log.info("Admin Views All Customers");

		model.addAttribute("customer", customer);

		return "viewAll";

	}
	
}
