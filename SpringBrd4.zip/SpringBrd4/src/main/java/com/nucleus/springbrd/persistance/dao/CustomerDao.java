package com.nucleus.springbrd.persistance.dao;





/********************************************************           
 * CustomerDao: Interface For Dao Operations            *   
 *                                                      *   
 * Author:  NIKHIL GUPTA                                *   
 *                                                      *   
 * Purpose: Declare All the methods implemented in Dao  *   
 *                                                      *   
 * Usage: Implemented upon CustomerDaoImpl              *   
 *      	        									*   
 ********************************************************/  



import java.util.List;

import com.nucleus.springbrd.persistance.entity.Customer;




//Interface:For Customer Records
public interface CustomerDao 

{
	
	public Customer addCustomer(Customer customer);
	
	public List<Customer> getAllCustomers();
	public Customer viewCustomerByCode(int customerCode);
	public List<Customer> getAllCustomersByName(String customerName);
	
	public Customer updateCustomer(Customer customer);
	public void deleteCustomer(int customerCode);
	
	

}
