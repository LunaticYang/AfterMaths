package com.nucleus.springbrd.service;
import java.util.logging.Logger;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.nucleus.springbrd.persistance.entity.User;



	public class PasswordEncrypt  
	{

		//logger
		static Logger log = Logger.getLogger(PasswordEncrypt.class.getName());
		

		//Instantiate Encrypter
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		

		//Encrypting User Password
		public void encryptPass(User user)
		{
			String pass = passwordEncoder.encode(user.getPassword());
			user.setPassword(pass);
		}
	}


