package com.nucleus.springbrd.controller;



import java.security.Principal;
import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.springbrd.persistance.entity.Customer;
import com.nucleus.springbrd.persistance.entity.User;
import com.nucleus.springbrd.service.CustomerService;
import com.nucleus.springbrd.service.UserService;
import com.nucleus.springbrd.service.ValidationService;




/********************************************************           
 * MainController --Handling  Requests                  *   
 *                                                      *   
 * Author:  NIKHIL GUPTA                                *   
 *                                                      *   
 * Purpose: Handles Authenticated User Request          *   
 *                                                      *   
 * Usage:  Dispatch Page Request                        *   
 *      		                                        *   
 ********************************************************/  






@Controller
public class UserController 
{

	
	//Logger to MainController
		final static Logger log = Logger.getLogger(UserController.class.getName());
	
	
	
	//Autowiring
		@Autowired
		CustomerService customerService;
	
	
		@Autowired
		ValidationService validationService;
	
	
		@Autowired
		UserService userService;




		
		

//USER SCREEN
//============================================================================================================


	// Load User-screen -----------------
	@RequestMapping(value = "/split")
	public String ShowCustomerHomePage() 
	{
		return "Split";
	}

	



//ADD RECORDS
//-------------------------------------------------------------------------------------------------------




//Add Record------------------------------------------

	//Load New Record Form
	@RequestMapping("/addCustomer")
	public ModelAndView ShowCustomerForm(Customer customer) 
	{
		log.info("Loading New Customer Form");

		//List<Country> theCountry = customerService.getCountries();

		return new ModelAndView("NewCustomerDetails");

	}




//Add Record To DataBase
	@RequestMapping("/newCustomer")
	public ModelAndView addnewUser(@Valid @ModelAttribute(value="customer") Customer customer, BindingResult result,
			                        Principal principal) 
	{
		if(result.hasErrors())
		{
			return new ModelAndView("NewCustomerDetails");
		}
		

		log.info("Validating Customer Details");
		int customerCode = customer.getCustomerCode();
		
		Customer theCustomer = customerService.viewCustomer(customerCode);
		
		if (theCustomer != null) 
		{
		  log.info("CustomerCode: " + customerCode + " Exists");
		  return new ModelAndView("NewCustomerDetails", "error", "Customer with" + customerCode + " Code Already Exists");
		}

		else
		{
			customer.setCreatedBy(principal.getName());
			customerService.addcustomer(customer);
			log.info("Customer Added Successfully by User" + principal.getName());
		
			return new ModelAndView("NewCustomerDetails", "success", "Customer Record was Added SuccessFully");
		}

	}




//VIEW - ALL CUSTOMER RECORDS
//-----------------------------------------------------------------------------------------------------------------




//View Records-------------------------------------------------
	@RequestMapping(value = "/viewall", method = RequestMethod.GET)
	public String viewAllUsers(Model model) 
	{
		log.info("Requesting to view all customer records");
		List<Customer> customer = customerService.viewAll();

		model.addAttribute("customer", customer);
		log.info("Displaying All Customer Records");
		return "viewAll"; 

	}







//VIEW - BY CODE
//-----------------------------------------------------------------------------------------------------------------



	//View Record by Code
	@RequestMapping(value = "/viewCustomer", method = RequestMethod.GET)
	public String getCodeForSingleView() 
	{
		log.info("Request For single View BY Code");
		return "singleviewload";

	}


	//View Record by code
	@RequestMapping(value = "/oneview", method = RequestMethod.POST)
	public ModelAndView oneview(Model model,@RequestParam("customerCode") String customerCode) 
	{

		int flag = validationService.validateCustomerCode(customerCode);
		if (flag == 2) 
		{
			log.error("Customer Code is  null");
			return new ModelAndView("singleviewload", "error" , "You must enter the Customer Code");
		}



		Customer customer = customerService.viewCustomer(Integer.parseInt(customerCode));
		
		model.addAttribute("customer", customer);
		

		if (customer != null) 
		{
			log.info("Displaying Customer");
			return new ModelAndView("singleViewDisplay");
		} 

		else 

		{
			log.fatal("Customer With that Code Not found");
			return new ModelAndView("singleviewload", "error",
					"No Customer With code:" + customerCode + "exist");
		}

	}








//VIEW- BY NAME
//-----------------------------------------------------------------------------------------------------------------





	//View Record By Name 
	@RequestMapping(value = "/viewByName", method = RequestMethod.GET)
	public String viewByName() 
	{
		log.info("Request for Displaying Customers By names");
		return "LoadCustomerName";
	}


	//View Record
	@RequestMapping(value = "/viewByInputName", method = RequestMethod.POST)
	public ModelAndView viewByInputName(Model model,@RequestParam("customerName") String customerName, @ModelAttribute Customer customer) 
	{
		log.info("Loading list Of Customers By That name");
		List<Customer> cust = null;
		cust = customerService.viewCustomersByName(customerName);

		if (cust.size() > 0) 
		{
			log.info("Displaying Customers");
			model.addAttribute("customer", cust);
			return new ModelAndView("viewByName");
		} 

		else 
		{
			log.fatal("No Customers Found");
			return new ModelAndView("LoadCustomerName", "error","No Customer Found With That name.");
		}

	}








//UPDATE RECORD
//-----------------------------------------------------------------------------------------------------------------



	//Update Customer Record by Code
	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public String updateUser() 
	{
		log.info("Request To Update customer");
		return "updateCustomerLoad";

	}


	//Get Record To Update
	@RequestMapping(value = "/updatevalue", method = RequestMethod.POST)
	public ModelAndView updateValue(Model model,@RequestParam("customerCode") String customerCode, @ModelAttribute Customer customer) 
	{

		log.info("Getting Code from customer");
		customer = customerService.viewCustomer(Integer.parseInt(customerCode));

		int flag = validationService.validateCustomerCode(customerCode);
		
		if (flag == 2) 
		{
			log.error("customer code was not inserted");
			return new ModelAndView("updateCustomerLoad", "error","Enter Customer code");
		}



		model.addAttribute("customer", customer);
		if (customer != null) 
		{
			log.info("Updating customer");
			return new ModelAndView("UpdateCustomer");
		} 

		else 

		{
			log.error("Customer was Not found");
			return new ModelAndView("updateCustomerLoad", "error","No Customer Could Be Found By That Code");
		}
	}



	//Update the Selected Record
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public ModelAndView updated(@Valid @ModelAttribute(value="customer")Customer customer, BindingResult result) {
		
		if(result.hasErrors())
		{
			return new ModelAndView("UpdateCustomer");
		}


		customerService.updateCustomer(customer);
		log.info("Updated Successfully");
		return new ModelAndView("UpdateCustomer", "success","Updation was successful");

		}






//DELETE RECORD
//-----------------------------------------------------------------------------------------------------------------




	//Delete Record
	@RequestMapping(value = "/deleteCustomer", method = RequestMethod.GET)
	public String getCodeToDelete() 
	{
	
		log.info("Getting Form For Taking Customer Code To Delete");
		return "DeleteView";
	}




	//Delete Selected Record
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public ModelAndView delete(Model model,@RequestParam("customerCode") String customerCode) 
	{

		int custCode = Integer.parseInt(customerCode);

		int flag = validationService.validateCustomerCode(customerCode);
		
		if (flag == 1) 
		{
			log.info("Checking If Customer Exists");
			return new ModelAndView("DeleteView" , "success" , "Customer Does Not Exist");
												
		} 

		else if (flag == 2) 
		{
			log.error("Didn't entered Customer Code ");
			return new ModelAndView("DeleteView" , "success" , "Enter Customer Code");
		} 

		else 
		{
			customerService.deleteCustomer(custCode);
			log.info("SuccessFully Deleted");
			return new ModelAndView("DeleteView", "success", "Customer was Deleted Successfully");
		}

	}






}
