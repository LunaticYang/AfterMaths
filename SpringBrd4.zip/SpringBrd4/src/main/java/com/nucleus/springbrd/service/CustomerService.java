package com.nucleus.springbrd.service;

import java.util.List;
import com.nucleus.springbrd.persistance.entity.Customer;





/********************************************************           
 * CustomerService --Interface For service Operations   *   
 *                                                      *   
 * Author:  NIKHIL GUPTA                                *   
 *                                                      *   
 * Purpose: Declare All the methods in 					*
 			CustomerServiceImpl                         *   
 *                                                      *   
 * Usage:   implemented on CustomerServiceImpl          *   
 *      	                                            *   
 ********************************************************/










//Interface: Customer Record Services Enlisted
public interface CustomerService 
{

	public Customer addcustomer(Customer customer);
	public void deleteCustomer(int customerCode);
	public Customer viewCustomer(int customerCode);
	public List<Customer> viewCustomersByName(String customerName);
	public List<Customer> viewAll();
	public Customer updateCustomer(Customer customer);

}
