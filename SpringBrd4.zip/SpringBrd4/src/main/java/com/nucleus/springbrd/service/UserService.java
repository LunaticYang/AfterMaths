package com.nucleus.springbrd.service;

import java.util.List;
import com.nucleus.springbrd.persistance.entity.User;







/********************************************************           
 * CustomerService --Interface For service Operations   *   
 *                                                      *   
 * Author:  NIKHIL GUPTA                                *   
 *                                                      *   
 * Purpose: Declare All the methods in 					*
 			UserServiceImpl   		                    *   
 *                                                      *   
 * Usage:   implemented on UserServiceImpl              *   
 *      	                                            *   
 ********************************************************/







public interface UserService 
{

	public User adduser(User user);
	public void deleteUser(int id);
	public List<User> viewAllUser();

	
}

