package com.and.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;





/********************************************************           
 * Handling --Dispatching Login page Requests.          *   
 *                                                      *   
 * Author:  NIKHIL GUPTA                                *   
 *                                                      *   
 * Purpose: Validate the User                           *   
 *                                                      *   
 * Usage:   Authenticate Verified User                  *   
 *          				        					*   
 ********************************************************/  




@Controller
public class LoginController 
{


	//Logger for LoginController Class
	final static Logger LOGGER = Logger.getLogger(LoginController.class);
	



   //To Login Page
	@RequestMapping("/login")
	public String showLoginPage() 
	{
		return "login";
	}



	//Any Error Handler
	@RequestMapping("/errorpage") 
	public ModelAndView errorHandler() 
	{
		return new ModelAndView("errorpage");
	}
	



	//Back To Login Page in case of failure
	@RequestMapping("/failure")
	public ModelAndView authenticationFailed() 
	{
		return new ModelAndView("login", "error", "In-valid credentials");
	}



	//Screen Handler
	@RequestMapping("/defaultPage")
	public String ScreenHandler(HttpServletRequest request) {

		String targetUrl = null;
		if (request.isUserInRole("ROLE_USER")) 
		{
			targetUrl = "/Split";
		} else if (request.isUserInRole("ROLE_ADMIN")) 
		{
			targetUrl = "/SplitUser";
		}

		return targetUrl;
	}

}
