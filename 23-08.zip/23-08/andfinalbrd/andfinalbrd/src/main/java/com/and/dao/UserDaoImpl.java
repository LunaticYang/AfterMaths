package com.and.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.and.model.User;




/*********************************************************           
 * CustomerDaoImpl --Database Queries to Implement       *
 *                   over Customer Records               *   
 *                                                       *   
 * Author:  NIKHIL GUPTA                                 *   
 *                                                       *   
 * Purpose: Perform CRUD operation                       *   
 *                                                       *   
 * Usage: Data can be Added, Viewed, Updated or, Deleted *   
 *      										         *   
 ********************************************************/   




@Repository
public class UserDaoImpl implements UserDao 
{

	@Autowired
	SessionFactory factory;
	

	//Logger: for Cases Encounters
	final static Logger log = Logger.getLogger(UserDaoImpl.class.getName());
	




//CRUD - ADD USERS--------------------------------------------------------------------------------------
	
	public User addUser(User user) 
	{
		try
		{
			log.debug("adding user");
			factory.getCurrentSession().save(user);
		}

		catch (HibernateException e) 
		{
			log.error("could not add" + e.getMessage());
		}

		catch (Exception e) 
		{
			log.error("could not add" + e.getMessage());
		}
		
		return user;
	}
 




//CRUD - DELETE USERS ----------------------------------------------------------------------------------------
	
	public void deleteUser(int id) 
	{ 
		User user = new User();
		user.setId(id);
	
		try
		{
			log.debug("in Dao for deleting user");
			factory.getCurrentSession().delete(user);
		}
	
		catch(HibernateException e)
		{
			log.error("could not delte" + e.getMessage());
		}
		
		catch(Exception e)
		{
			log.error("could not delte" + e.getMessage());
		}
	}




//CRUD - VIEW ALL USERS ----------------------------------------------------------------------------------
	
	@SuppressWarnings("unchecked")
	public List<User> getAllUser() 
	{ 
		List<User> list=new ArrayList<User>();
	
		try
		{
			log.debug("getting list of user");
			list= factory.getCurrentSession().createCriteria(User.class).list();
		}

		catch (HibernateException e) 
		{
			log.error("could not find" + e.getMessage());
		}

		catch(Exception e)
		{
			log.error("could not find" + e.getMessage());
		}
		return list;
	}

}
