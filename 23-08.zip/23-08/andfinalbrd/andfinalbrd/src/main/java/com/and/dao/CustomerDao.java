package com.and.dao;



/********************************************************           
 * CustomerDao: Interface For Dao Operations            *   
 *                                                      *   
 * Author:  NIKHIL GUPTA                                *   
 *                                                      *   
 * Purpose: Declare All the methods implemented in Dao  *   
 *                                                      *   
 * Usage: Implemented upon CustomerDaoImpl              *   
 *      	        									*   
 ********************************************************/  



import java.util.List;

import com.and.model.Customer;


//Interface:Customer Records to Database handler
public interface CustomerDao 

{
	
	public Customer addCustomer(Customer customer);
	public void deleteCustomer(int customerCode);
	public Customer viewCustomerByCode(int customerCode);
	public List<Customer> getAllCustomers();
	public Customer updateCustomer(Customer customer);
	public List<Customer> getAllCustomersByName(String customerName);
	

}
