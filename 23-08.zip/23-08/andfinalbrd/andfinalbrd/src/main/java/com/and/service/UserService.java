package com.and.service;




/********************************************************           
 * CustomerService --Interface For service Operations   *   
 *                                                      *   
 * Author:  NiKHIL GUPTA                                *   
 *                                                      *   
 * Purpose: Declare All the methods in 					*
 			UserServiceImpl   		                    *   
 *                                                      *   
 * Usage:   implemented on UserServiceImpl              *   
 *      	                                            *   
 ********************************************************/



import java.util.List;

import com.and.model.User;


public interface UserService 
{

	public User adduser(User user);
	public void deleteUser(int id);
	public List<User> viewAllUser();

	
}

