package com.and.service;




/********************************************************           
 * CustomerService --Interface For service Operations   *   
 *                                                      *   
 * Author:  NiKHIL GUPTA                                *   
 *                                                      *   
 * Purpose: Declare All the methods in 					*
 			CustomerServiceImpl                         *   
 *                                                      *   
 * Usage:   implemented on CustomerServiceImpl          *   
 *      	                                            *   
 ********************************************************/




import java.util.List;

import com.and.model.Customer;



//Interface: Customer Record Services Enlisted
public interface CustomerService 
{

	public Customer addcustomer(Customer customer);
	public void deleteCustomer(int customerCode);
	public Customer viewCustomer(int customerCode);
	public List<Customer> viewCustomersByName(String customerName);
	public List<Customer> viewAll();
	public Customer updateCustomer(Customer customer);

}
